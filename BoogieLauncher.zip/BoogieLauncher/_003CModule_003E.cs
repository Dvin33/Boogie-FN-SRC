﻿
using Costura;

internal class \u003CModule\u003E
{
  static \u003CModule\u003E() => AssemblyLoader.Attach();
}
