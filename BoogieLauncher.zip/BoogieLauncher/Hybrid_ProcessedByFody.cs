﻿// Decompiled with JetBrains decompiler
// Type: Hybrid_ProcessedByFody
// Assembly: Hybrid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 03FB1C8F-A1FB-45A7-9E37-687AFF18BB84
// Assembly location: C:\Users\ekand\Desktop\privaterser\BoogieLauncher.exe

internal class Hybrid_ProcessedByFody
{
  internal const string FodyVersion = "6.5.5.0";
  internal const string Costura = "5.7.0";
}
