﻿// Decompiled with JetBrains decompiler
// Type: Costura.AssemblyLoader
// Assembly: Hybrid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 03FB1C8F-A1FB-45A7-9E37-687AFF18BB84
// Assembly location: C:\Users\ekand\Desktop\privaterser\BoogieLauncher.exe

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;

namespace Costura
{
  [CompilerGenerated]
  internal static class AssemblyLoader
  {
    private static object nullCacheLock = new object();
    private static Dictionary<string, bool> nullCache = new Dictionary<string, bool>();
    private static Dictionary<string, string> assemblyNames = new Dictionary<string, string>();
    private static Dictionary<string, string> symbolNames = new Dictionary<string, string>();
    private static int isAttached;

    private static string CultureToString(CultureInfo culture) => culture == null ? "" : culture.Name;

    private static Assembly ReadExistingAssembly(AssemblyName name)
    {
      foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
      {
        AssemblyName name1 = assembly.GetName();
        // ISSUE: reference to a compiler-generated method
        // ISSUE: reference to a compiler-generated method
        if (string.Equals(name1.Name, name.Name, StringComparison.InvariantCultureIgnoreCase) && string.Equals(AssemblyLoader.CultureToString(name1.CultureInfo), AssemblyLoader.CultureToString(name.CultureInfo), StringComparison.InvariantCultureIgnoreCase))
          return assembly;
      }
      return (Assembly) null;
    }

    private static void CopyTo(Stream source, Stream destination)
    {
      byte[] buffer = new byte[81920];
      int count;
      while ((count = source.Read(buffer, 0, buffer.Length)) != 0)
        destination.Write(buffer, 0, count);
    }

    private static Stream LoadStream(string fullName)
    {
      Assembly executingAssembly = Assembly.GetExecutingAssembly();
      if (!fullName.EndsWith(".compressed"))
        return executingAssembly.GetManifestResourceStream(fullName);
      using (Stream manifestResourceStream = executingAssembly.GetManifestResourceStream(fullName))
      {
        using (DeflateStream source = new DeflateStream(manifestResourceStream, CompressionMode.Decompress))
        {
          MemoryStream destination = new MemoryStream();
          // ISSUE: reference to a compiler-generated method
          AssemblyLoader.CopyTo((Stream) source, (Stream) destination);
          destination.Position = 0L;
          return (Stream) destination;
        }
      }
    }

    private static Stream LoadStream(Dictionary<string, string> resourceNames, string name)
    {
      string fullName;
      // ISSUE: reference to a compiler-generated method
      return resourceNames.TryGetValue(name, out fullName) ? AssemblyLoader.LoadStream(fullName) : (Stream) null;
    }

    private static byte[] ReadStream(Stream stream)
    {
      byte[] buffer = new byte[stream.Length];
      stream.Read(buffer, 0, buffer.Length);
      return buffer;
    }

    private static Assembly ReadFromEmbeddedResources(
      Dictionary<string, string> assemblyNames,
      Dictionary<string, string> symbolNames,
      AssemblyName requestedAssemblyName)
    {
      string name = requestedAssemblyName.Name.ToLowerInvariant();
      if (requestedAssemblyName.CultureInfo != null && !string.IsNullOrEmpty(requestedAssemblyName.CultureInfo.Name))
        name = requestedAssemblyName.CultureInfo.Name + "." + name;
      byte[] rawAssembly;
      // ISSUE: reference to a compiler-generated method
      using (Stream stream = AssemblyLoader.LoadStream(assemblyNames, name))
      {
        if (stream == null)
          return (Assembly) null;
        // ISSUE: reference to a compiler-generated method
        rawAssembly = AssemblyLoader.ReadStream(stream);
      }
      // ISSUE: reference to a compiler-generated method
      using (Stream stream = AssemblyLoader.LoadStream(symbolNames, name))
      {
        if (stream != null)
        {
          // ISSUE: reference to a compiler-generated method
          byte[] rawSymbolStore = AssemblyLoader.ReadStream(stream);
          return Assembly.Load(rawAssembly, rawSymbolStore);
        }
      }
      return Assembly.Load(rawAssembly);
    }

    public static Assembly ResolveAssembly(object sender, ResolveEventArgs e)
    {
      // ISSUE: reference to a compiler-generated field
      lock (AssemblyLoader.nullCacheLock)
      {
        // ISSUE: reference to a compiler-generated field
        if (AssemblyLoader.nullCache.ContainsKey(e.Name))
          return (Assembly) null;
      }
      AssemblyName assemblyName = new AssemblyName(e.Name);
      // ISSUE: reference to a compiler-generated method
      Assembly assembly1 = AssemblyLoader.ReadExistingAssembly(assemblyName);
      if ((object) assembly1 != null)
        return assembly1;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated method
      Assembly assembly2 = AssemblyLoader.ReadFromEmbeddedResources(AssemblyLoader.assemblyNames, AssemblyLoader.symbolNames, assemblyName);
      if ((object) assembly2 == null)
      {
        // ISSUE: reference to a compiler-generated field
        lock (AssemblyLoader.nullCacheLock)
        {
          // ISSUE: reference to a compiler-generated field
          AssemblyLoader.nullCache[e.Name] = true;
        }
        if ((assemblyName.Flags & AssemblyNameFlags.Retargetable) != AssemblyNameFlags.None)
          assembly2 = Assembly.Load(assemblyName);
      }
      return assembly2;
    }

    static AssemblyLoader()
    {
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("af-za.modernwpf.controls.resources", "costura.af-za.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("af-za.modernwpf.resources", "costura.af-za.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("am-et.modernwpf.controls.resources", "costura.am-et.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("am-et.modernwpf.resources", "costura.am-et.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ar-sa.modernwpf.controls.resources", "costura.ar-sa.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ar-sa.modernwpf.resources", "costura.ar-sa.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("az-latn-az.modernwpf.controls.resources", "costura.az-latn-az.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("az-latn-az.modernwpf.resources", "costura.az-latn-az.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("be-by.modernwpf.controls.resources", "costura.be-by.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("be-by.modernwpf.resources", "costura.be-by.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("bg-bg.modernwpf.controls.resources", "costura.bg-bg.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("bg-bg.modernwpf.resources", "costura.bg-bg.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("bn-bd.modernwpf.controls.resources", "costura.bn-bd.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("bn-bd.modernwpf.resources", "costura.bn-bd.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("bs-latn-ba.modernwpf.controls.resources", "costura.bs-latn-ba.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("bs-latn-ba.modernwpf.resources", "costura.bs-latn-ba.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ca-es.modernwpf.controls.resources", "costura.ca-es.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ca-es.modernwpf.resources", "costura.ca-es.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("commonwin32", "costura.commonwin32.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.symbolNames.Add("commonwin32", "costura.commonwin32.pdb.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("costura", "costura.costura.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.symbolNames.Add("costura", "costura.costura.pdb.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("cs-cz.modernwpf.controls.resources", "costura.cs-cz.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("cs-cz.modernwpf.resources", "costura.cs-cz.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("da-dk.modernwpf.controls.resources", "costura.da-dk.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("da-dk.modernwpf.resources", "costura.da-dk.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("de-de.modernwpf.controls.resources", "costura.de-de.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("de-de.modernwpf.resources", "costura.de-de.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("el-gr.modernwpf.controls.resources", "costura.el-gr.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("el-gr.modernwpf.resources", "costura.el-gr.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("en-gb.modernwpf.controls.resources", "costura.en-gb.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("en-gb.modernwpf.resources", "costura.en-gb.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("es-es.modernwpf.controls.resources", "costura.es-es.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("es-es.modernwpf.resources", "costura.es-es.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("es-mx.modernwpf.controls.resources", "costura.es-mx.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("es-mx.modernwpf.resources", "costura.es-mx.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("et-ee.modernwpf.controls.resources", "costura.et-ee.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("et-ee.modernwpf.resources", "costura.et-ee.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("eu-es.modernwpf.controls.resources", "costura.eu-es.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("eu-es.modernwpf.resources", "costura.eu-es.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("fa-ir.modernwpf.controls.resources", "costura.fa-ir.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("fa-ir.modernwpf.resources", "costura.fa-ir.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("fi-fi.modernwpf.controls.resources", "costura.fi-fi.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("fi-fi.modernwpf.resources", "costura.fi-fi.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("fluentwpf", "costura.fluentwpf.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("fr-ca.modernwpf.controls.resources", "costura.fr-ca.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("fr-ca.modernwpf.resources", "costura.fr-ca.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("fr-fr.modernwpf.controls.resources", "costura.fr-fr.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("fr-fr.modernwpf.resources", "costura.fr-fr.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("gl-es.modernwpf.controls.resources", "costura.gl-es.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("gl-es.modernwpf.resources", "costura.gl-es.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ha-latn-ng.modernwpf.controls.resources", "costura.ha-latn-ng.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ha-latn-ng.modernwpf.resources", "costura.ha-latn-ng.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("he-il.modernwpf.controls.resources", "costura.he-il.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("he-il.modernwpf.resources", "costura.he-il.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("hi-in.modernwpf.controls.resources", "costura.hi-in.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("hi-in.modernwpf.resources", "costura.hi-in.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("hr-hr.modernwpf.controls.resources", "costura.hr-hr.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("hr-hr.modernwpf.resources", "costura.hr-hr.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("hu-hu.modernwpf.controls.resources", "costura.hu-hu.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("hu-hu.modernwpf.resources", "costura.hu-hu.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("id-id.modernwpf.controls.resources", "costura.id-id.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("id-id.modernwpf.resources", "costura.id-id.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("is-is.modernwpf.controls.resources", "costura.is-is.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("is-is.modernwpf.resources", "costura.is-is.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("it-it.modernwpf.controls.resources", "costura.it-it.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("it-it.modernwpf.resources", "costura.it-it.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ja-jp.modernwpf.controls.resources", "costura.ja-jp.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ja-jp.modernwpf.resources", "costura.ja-jp.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ka-ge.modernwpf.controls.resources", "costura.ka-ge.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ka-ge.modernwpf.resources", "costura.ka-ge.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("kk-kz.modernwpf.controls.resources", "costura.kk-kz.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("kk-kz.modernwpf.resources", "costura.kk-kz.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("km-kh.modernwpf.controls.resources", "costura.km-kh.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("km-kh.modernwpf.resources", "costura.km-kh.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("kn-in.modernwpf.controls.resources", "costura.kn-in.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("kn-in.modernwpf.resources", "costura.kn-in.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ko-kr.modernwpf.controls.resources", "costura.ko-kr.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ko-kr.modernwpf.resources", "costura.ko-kr.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("lo-la.modernwpf.controls.resources", "costura.lo-la.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("lo-la.modernwpf.resources", "costura.lo-la.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("lt-lt.modernwpf.controls.resources", "costura.lt-lt.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("lt-lt.modernwpf.resources", "costura.lt-lt.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("lv-lv.modernwpf.controls.resources", "costura.lv-lv.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("lv-lv.modernwpf.resources", "costura.lv-lv.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("microsoft.bcl.asyncinterfaces", "costura.microsoft.bcl.asyncinterfaces.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("microsoft.toolkit.uwp.notifications", "costura.microsoft.toolkit.uwp.notifications.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.symbolNames.Add("microsoft.toolkit.uwp.notifications", "costura.microsoft.toolkit.uwp.notifications.pdb.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("microsoft.windowsapicodepack", "costura.microsoft.windowsapicodepack.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("microsoft.windowsapicodepack.shell", "costura.microsoft.windowsapicodepack.shell.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("mk-mk.modernwpf.controls.resources", "costura.mk-mk.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("mk-mk.modernwpf.resources", "costura.mk-mk.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ml-in.modernwpf.controls.resources", "costura.ml-in.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ml-in.modernwpf.resources", "costura.ml-in.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("modernwpf.controls", "costura.modernwpf.controls.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("modernwpf", "costura.modernwpf.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ms-my.modernwpf.controls.resources", "costura.ms-my.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ms-my.modernwpf.resources", "costura.ms-my.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("nb-no.modernwpf.controls.resources", "costura.nb-no.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("nb-no.modernwpf.resources", "costura.nb-no.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("nl-nl.modernwpf.controls.resources", "costura.nl-nl.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("nl-nl.modernwpf.resources", "costura.nl-nl.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("nn-no.modernwpf.controls.resources", "costura.nn-no.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("nn-no.modernwpf.resources", "costura.nn-no.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("pl-pl.modernwpf.controls.resources", "costura.pl-pl.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("pl-pl.modernwpf.resources", "costura.pl-pl.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("pt-br.modernwpf.controls.resources", "costura.pt-br.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("pt-br.modernwpf.resources", "costura.pt-br.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("pt-pt.modernwpf.controls.resources", "costura.pt-pt.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("pt-pt.modernwpf.resources", "costura.pt-pt.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("restsharp", "costura.restsharp.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ro-ro.modernwpf.controls.resources", "costura.ro-ro.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ro-ro.modernwpf.resources", "costura.ro-ro.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ru-ru.modernwpf.controls.resources", "costura.ru-ru.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ru-ru.modernwpf.resources", "costura.ru-ru.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sk-sk.modernwpf.controls.resources", "costura.sk-sk.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sk-sk.modernwpf.resources", "costura.sk-sk.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sl-si.modernwpf.controls.resources", "costura.sl-si.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sl-si.modernwpf.resources", "costura.sl-si.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sq-al.modernwpf.controls.resources", "costura.sq-al.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sq-al.modernwpf.resources", "costura.sq-al.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sr-latn-rs.modernwpf.controls.resources", "costura.sr-latn-rs.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sr-latn-rs.modernwpf.resources", "costura.sr-latn-rs.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sv-se.modernwpf.controls.resources", "costura.sv-se.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sv-se.modernwpf.resources", "costura.sv-se.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sw-ke.modernwpf.controls.resources", "costura.sw-ke.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("sw-ke.modernwpf.resources", "costura.sw-ke.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("system.buffers", "costura.system.buffers.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("system.diagnostics.diagnosticsource", "costura.system.diagnostics.diagnosticsource.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("system.memory", "costura.system.memory.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("system.numerics.vectors", "costura.system.numerics.vectors.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("system.runtime.compilerservices.unsafe", "costura.system.runtime.compilerservices.unsafe.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("system.text.encodings.web", "costura.system.text.encodings.web.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("system.text.json", "costura.system.text.json.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("system.threading.tasks.extensions", "costura.system.threading.tasks.extensions.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("system.valuetuple", "costura.system.valuetuple.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ta-in.modernwpf.controls.resources", "costura.ta-in.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("ta-in.modernwpf.resources", "costura.ta-in.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("te-in.modernwpf.controls.resources", "costura.te-in.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("te-in.modernwpf.resources", "costura.te-in.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("th-th.modernwpf.controls.resources", "costura.th-th.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("th-th.modernwpf.resources", "costura.th-th.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("tr-tr.modernwpf.controls.resources", "costura.tr-tr.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("tr-tr.modernwpf.resources", "costura.tr-tr.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("uk-ua.modernwpf.controls.resources", "costura.uk-ua.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("uk-ua.modernwpf.resources", "costura.uk-ua.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("uz-latn-uz.modernwpf.controls.resources", "costura.uz-latn-uz.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("uz-latn-uz.modernwpf.resources", "costura.uz-latn-uz.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("vi-vn.modernwpf.controls.resources", "costura.vi-vn.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("vi-vn.modernwpf.resources", "costura.vi-vn.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("zh-cn.modernwpf.controls.resources", "costura.zh-cn.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("zh-cn.modernwpf.resources", "costura.zh-cn.modernwpf.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("zh-tw.modernwpf.controls.resources", "costura.zh-tw.modernwpf.controls.resources.dll.compressed");
      // ISSUE: reference to a compiler-generated field
      AssemblyLoader.assemblyNames.Add("zh-tw.modernwpf.resources", "costura.zh-tw.modernwpf.resources.dll.compressed");
    }

    public static void Attach()
    {
      // ISSUE: reference to a compiler-generated field
      if (Interlocked.Exchange(ref AssemblyLoader.isAttached, 1) == 1)
        return;
      AppDomain.CurrentDomain.AssemblyResolve += (ResolveEventHandler) ((sender, e) =>
      {
        // ISSUE: reference to a compiler-generated field
        lock (AssemblyLoader.nullCacheLock)
        {
          // ISSUE: reference to a compiler-generated field
          if (AssemblyLoader.nullCache.ContainsKey(e.Name))
            return (Assembly) null;
        }
        AssemblyName assemblyName = new AssemblyName(e.Name);
        // ISSUE: reference to a compiler-generated method
        Assembly assembly1 = AssemblyLoader.ReadExistingAssembly(assemblyName);
        if ((object) assembly1 != null)
          return assembly1;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        Assembly assembly2 = AssemblyLoader.ReadFromEmbeddedResources(AssemblyLoader.assemblyNames, AssemblyLoader.symbolNames, assemblyName);
        if ((object) assembly2 == null)
        {
          // ISSUE: reference to a compiler-generated field
          lock (AssemblyLoader.nullCacheLock)
          {
            // ISSUE: reference to a compiler-generated field
            AssemblyLoader.nullCache[e.Name] = true;
          }
          if ((assemblyName.Flags & AssemblyNameFlags.Retargetable) != AssemblyNameFlags.None)
            assembly2 = Assembly.Load(assemblyName);
        }
        return assembly2;
      });
    }
  }
}
