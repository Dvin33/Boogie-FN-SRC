﻿// Decompiled with JetBrains decompiler
// Type: Hybrid.MainWindow
// Assembly: Hybrid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 03FB1C8F-A1FB-45A7-9E37-687AFF18BB84
// Assembly location: C:\Users\ekand\Desktop\privaterser\BoogieLauncher.exe

namespace Hybrid
{
    internal class CommonFileDialog
    {
    }
}