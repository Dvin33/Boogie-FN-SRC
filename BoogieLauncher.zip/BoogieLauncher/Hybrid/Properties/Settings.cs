﻿// Decompiled with JetBrains decompiler
// Type: Hybrid.Properties.Settings
// Assembly: Hybrid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 03FB1C8F-A1FB-45A7-9E37-687AFF18BB84
// Assembly location: C:\Users\ekand\Desktop\privaterser\BoogieLauncher.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace Hybrid.Properties
{
  [CompilerGenerated]
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
  internal sealed class Settings : ApplicationSettingsBase
  {
    private static Settings defaultInstance = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());

    public static Settings Default => Settings.defaultInstance;
  }
}
