﻿// Decompiled with JetBrains decompiler
// Type: Hybrid.App
// Assembly: Hybrid, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 03FB1C8F-A1FB-45A7-9E37-687AFF18BB84
// Assembly location: C:\Users\ekand\Desktop\privaterser\BoogieLauncher.exe

using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

namespace Hybrid
{
  public class App : Application
  {
    private bool _contentLoaded;

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      this.StartupUri = new Uri("MainWindow.xaml", UriKind.Relative);
      Application.LoadComponent((object) this, new Uri("/Hybrid;component/app.xaml", UriKind.Relative));
    }

    [STAThread]
    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public static void Main()
    {
      App app = new App();
      app.InitializeComponent();
      app.Run();
    }
  }
}
